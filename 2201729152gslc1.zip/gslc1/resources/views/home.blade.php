@extends('template')

@section('title', 'Home')

@section('content')
    <h1>Ini Home </h1>

    @foreach($pokemonData as $pokemon)
        <img src ={{$pokemon->image_url}} alt="">
        <h1>{{$pokemon->name}}</h1>
        <h2>{{$pokemon->description}}</h2>
        <h2>{{$pokemon->type}}</h2>
    @endforeach
@endsection